"""
Vector Pulse - DDoS Detection System
Flask Backend API
"""

from flask import Flask, render_template, request, jsonify
import pickle, json, numpy as np, os, random, time

app = Flask(__name__)

# Load model artifacts
BASE = os.path.dirname(__file__)
with open(os.path.join(BASE, "model/rf_model.pkl"), "rb") as f:
    model = pickle.load(f)
with open(os.path.join(BASE, "model/scaler.pkl"), "rb") as f:
    scaler = pickle.load(f)
with open(os.path.join(BASE, "model/metadata.json")) as f:
    meta = json.load(f)

FEATURES = meta["features"]

# ── Live traffic simulator ──────────────────────────────────
def simulate_traffic(mode="mixed"):
    """Generate a random traffic sample for live demo."""
    if mode == "ddos":
        sample = {
            "packet_rate":        random.uniform(1500, 9000),
            "byte_rate":          random.uniform(50000, 400000),
            "avg_packet_size":    random.uniform(20, 120),
            "flow_duration":      random.uniform(0.01, 5),
            "src_ip_entropy":     random.uniform(0.1, 1.8),
            "dst_port_entropy":   random.uniform(0.0, 1.2),
            "tcp_syn_ratio":      random.uniform(0.75, 1.0),
            "udp_ratio":          random.uniform(0.0, 0.1),
            "icmp_ratio":         random.uniform(0.0, 0.05),
            "inter_arrival_mean": random.uniform(0.001, 2),
            "inter_arrival_std":  random.uniform(0.001, 1),
            "unique_src_ips":     random.randint(1, 5),
            "unique_dst_ports":   random.randint(1, 2),
            "fragment_ratio":     random.uniform(0.2, 0.9),
        }
    else:
        sample = {
            "packet_rate":        random.uniform(10, 300),
            "byte_rate":          random.uniform(500, 40000),
            "avg_packet_size":    random.uniform(400, 1400),
            "flow_duration":      random.uniform(5, 200),
            "src_ip_entropy":     random.uniform(3.5, 5.0),
            "dst_port_entropy":   random.uniform(2.0, 4.5),
            "tcp_syn_ratio":      random.uniform(0.01, 0.12),
            "udp_ratio":          random.uniform(0.05, 0.35),
            "icmp_ratio":         random.uniform(0.0, 0.04),
            "inter_arrival_mean": random.uniform(10, 150),
            "inter_arrival_std":  random.uniform(5, 80),
            "unique_src_ips":     random.randint(20, 180),
            "unique_dst_ports":   random.randint(5, 45),
            "fragment_ratio":     random.uniform(0.0, 0.04),
        }
    return sample

# ── Routes ──────────────────────────────────────────────────
@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/")
def index():
    return render_template("index.html", meta=meta)

@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.json
    features = data.get("features", {})

    # Build feature vector
    vec = np.array([[features.get(f, 0) for f in FEATURES]])
    vec_scaled = scaler.transform(vec)

    prediction = int(model.predict(vec_scaled)[0])
    proba = model.predict_proba(vec_scaled)[0].tolist()
    confidence = round(max(proba) * 100, 2)

    return jsonify({
        "prediction": prediction,
        "label": "DDoS" if prediction == 1 else "Benign",
        "confidence": confidence,
        "probabilities": {"benign": round(proba[0]*100,2), "ddos": round(proba[1]*100,2)},
        "timestamp": time.time()
    })

@app.route("/api/simulate", methods=["POST"])
def simulate():
    mode = request.json.get("mode", "mixed")
    if mode == "mixed":
        mode = "ddos" if random.random() < 0.4 else "benign"
    sample = simulate_traffic(mode)
    vec = np.array([[sample[f] for f in FEATURES]])
    vec_scaled = scaler.transform(vec)
    prediction = int(model.predict(vec_scaled)[0])
    proba = model.predict_proba(vec_scaled)[0].tolist()
    confidence = round(max(proba) * 100, 2)

    return jsonify({
        "features": {k: round(v, 4) for k, v in sample.items()},
        "prediction": prediction,
        "label": "DDoS" if prediction == 1 else "Benign",
        "confidence": confidence,
        "probabilities": {"benign": round(proba[0]*100,2), "ddos": round(proba[1]*100,2)},
        "timestamp": time.time()
    })

@app.route("/api/metadata")
def metadata():
    return jsonify(meta)

@app.route("/api/batch_simulate", methods=["POST"])
def batch_simulate():
    """Simulate a stream of 20 traffic samples for the dashboard."""
    results = []
    for _ in range(20):
        mode = "ddos" if random.random() < 0.35 else "benign"
        sample = simulate_traffic(mode)
        vec = np.array([[sample[f] for f in FEATURES]])
        vec_scaled = scaler.transform(vec)
        prediction = int(model.predict(vec_scaled)[0])
        proba = model.predict_proba(vec_scaled)[0].tolist()
        results.append({
            "features": {k: round(v, 4) for k, v in sample.items()},
            "prediction": prediction,
            "label": "DDoS" if prediction == 1 else "Benign",
            "confidence": round(max(proba)*100,2),
        })
    return jsonify(results)

if __name__ == "__main__":
    print("\n  VECTOR PULSE running at http://127.0.0.1:5000\n")
    app.run(debug=True, port=5000)
