# VECTOR PULSE — DDoS Detection System
### ML-Powered Network Traffic Classifier

---

## Overview

Vector Pulse is a machine learning-based DDoS (Distributed Denial of Service) **detection** system. It classifies network traffic flows as either **Benign** or **DDoS attack** using a trained Random Forest model.

This is a **defensive** security tool — it detects attacks, does not launch them.

---

## ML Pipeline

| Step | Description |
|------|-------------|
| **Dataset** | 10,000 synthetic traffic records (5K benign, 5K DDoS) |
| **Features** | 14 network flow features (packet rate, entropy, SYN ratio, etc.) |
| **Model** | Random Forest (150 estimators, max_depth=20) |
| **Preprocessing** | StandardScaler normalization |
| **Accuracy** | ~99%+ on test split |

### Features Used
- `packet_rate` — packets per second
- `byte_rate` — bytes per second
- `avg_packet_size` — mean packet size in bytes
- `flow_duration` — duration of the flow
- `src_ip_entropy` — entropy of source IP distribution (low = spoofed IPs)
- `dst_port_entropy` — entropy of destination ports
- `tcp_syn_ratio` — fraction of SYN packets (high = SYN flood)
- `udp_ratio` — fraction of UDP packets
- `icmp_ratio` — fraction of ICMP packets
- `inter_arrival_mean` / `inter_arrival_std` — timing statistics
- `unique_src_ips` — number of distinct source IPs
- `unique_dst_ports` — number of distinct destination ports
- `fragment_ratio` — fraction of fragmented packets

---

## Project Structure

```
vector-pulse/
├── app.py               ← Flask web server + REST API
├── train_model.py       ← ML training script
├── requirements.txt     ← Python dependencies
├── data/
│   └── network_traffic.csv    ← Generated dataset
├── model/
│   ├── rf_model.pkl     ← Trained Random Forest
│   ├── scaler.pkl       ← Feature scaler
│   └── metadata.json    ← Accuracy + feature importance
└── templates/
    └── index.html       ← Cybersecurity dashboard UI
```

---

## Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional) Retrain the model
python train_model.py

# 3. Start the web server
python app.py

# 4. Open browser
#    http://127.0.0.1:5000
```

---

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Dashboard UI |
| `/api/predict` | POST | Classify custom traffic features |
| `/api/simulate` | POST | Generate + classify random traffic |
| `/api/batch_simulate` | POST | Simulate 20 flows at once |
| `/api/metadata` | GET | Model accuracy + feature importance |

### Example: `/api/predict`
```json
POST /api/predict
{
  "features": {
    "packet_rate": 2500,
    "byte_rate": 90000,
    "tcp_syn_ratio": 0.92,
    ...
  }
}

Response:
{
  "prediction": 1,
  "label": "DDoS",
  "confidence": 97.3,
  "probabilities": { "benign": 2.7, "ddos": 97.3 }
}
```

---

## Dashboard Features

- **Live Auto-Scan** — continuously classifies simulated traffic flows
- **Real-time Chart** — 3-line traffic visualization (packet rate, DDoS confidence, byte rate)
- **Alert Banner** — flashing alert when DDoS detected
- **Manual Analysis** — enter custom traffic parameters and run prediction
- **Feature Importance** — bar chart showing which features matter most
- **Event Log** — real-time log of all classified flows
- **Metrics Panel** — running totals of flows, attacks, confidence

---

## Disclaimer

This tool is built for **educational and defensive purposes only**. It demonstrates how ML can be used to detect network attacks. It does not generate, launch, or facilitate any form of attack traffic.
