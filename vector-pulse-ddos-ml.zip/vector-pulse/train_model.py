"""
Vector Pulse - DDoS Detection ML Engine
Generates synthetic network traffic dataset and trains Random Forest classifier
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
import pickle
import json
import os

np.random.seed(42)

print("=" * 60)
print("  VECTOR PULSE - ML Model Training")
print("=" * 60)

# ─────────────────────────────────────────────
# 1. Generate Synthetic Network Traffic Dataset
# ─────────────────────────────────────────────
print("\n[1/4] Generating network traffic dataset...")

N_BENIGN = 5000
N_DDOS   = 5000

def gen_benign(n):
    return pd.DataFrame({
        "packet_rate":        np.random.normal(50,  20,  n).clip(1, 500),
        "byte_rate":          np.random.normal(5000, 2000, n).clip(100, 50000),
        "avg_packet_size":    np.random.normal(800, 200, n).clip(64, 1500),
        "flow_duration":      np.random.exponential(30, n).clip(0.1, 300),
        "src_ip_entropy":     np.random.uniform(3.5, 5.0, n),
        "dst_port_entropy":   np.random.uniform(2.0, 4.5, n),
        "tcp_syn_ratio":      np.random.uniform(0.01, 0.15, n),
        "udp_ratio":          np.random.uniform(0.05, 0.40, n),
        "icmp_ratio":         np.random.uniform(0.00, 0.05, n),
        "inter_arrival_mean": np.random.normal(20, 10, n).clip(0.1, 200),
        "inter_arrival_std":  np.random.normal(15, 8,  n).clip(0.1, 100),
        "unique_src_ips":     np.random.randint(5, 200, n),
        "unique_dst_ports":   np.random.randint(2, 50, n),
        "fragment_ratio":     np.random.uniform(0.00, 0.05, n),
        "label": 0,  # Benign
    })

def gen_ddos(n):
    attack_type = np.random.choice(["syn_flood","udp_flood","http_flood","icmp_flood"], n)
    df = pd.DataFrame({
        "packet_rate":        np.random.normal(2000, 800, n).clip(500, 10000),
        "byte_rate":          np.random.normal(80000, 30000, n).clip(10000, 500000),
        "avg_packet_size":    np.where(attack_type=="udp_flood",
                                np.random.normal(1400, 50, n),
                                np.random.normal(60, 20, n)).clip(20, 1500),
        "flow_duration":      np.random.exponential(2, n).clip(0.01, 30),
        "src_ip_entropy":     np.random.uniform(0.1, 2.0, n),
        "dst_port_entropy":   np.random.uniform(0.0, 1.5, n),
        "tcp_syn_ratio":      np.where(attack_type=="syn_flood",
                                np.random.uniform(0.80, 1.00, n),
                                np.random.uniform(0.00, 0.10, n)),
        "udp_ratio":          np.where(attack_type=="udp_flood",
                                np.random.uniform(0.85, 1.00, n),
                                np.random.uniform(0.00, 0.10, n)),
        "icmp_ratio":         np.where(attack_type=="icmp_flood",
                                np.random.uniform(0.80, 1.00, n),
                                np.random.uniform(0.00, 0.05, n)),
        "inter_arrival_mean": np.random.normal(0.5, 0.3, n).clip(0.001, 5),
        "inter_arrival_std":  np.random.normal(0.2, 0.1, n).clip(0.001, 2),
        "unique_src_ips":     np.random.randint(1, 10, n),
        "unique_dst_ports":   np.random.randint(1, 3, n),
        "fragment_ratio":     np.random.uniform(0.1, 0.8, n),
        "label": 1,  # DDoS
    })
    return df

df = pd.concat([gen_benign(N_BENIGN), gen_ddos(N_DDOS)], ignore_index=True).sample(frac=1, random_state=42)
df.to_csv("data/network_traffic.csv", index=False)
print(f"   Dataset: {len(df)} records ({N_BENIGN} benign, {N_DDOS} DDoS)")

# ─────────────────────────────────────────────
# 2. Preprocess
# ─────────────────────────────────────────────
print("\n[2/4] Preprocessing data...")
FEATURES = [c for c in df.columns if c != "label"]
X = df[FEATURES]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)
print(f"   Train: {len(X_train)} | Test: {len(X_test)}")

# ─────────────────────────────────────────────
# 3. Train Random Forest
# ─────────────────────────────────────────────
print("\n[3/4] Training Random Forest classifier...")
rf = RandomForestClassifier(
    n_estimators=150,
    max_depth=20,
    min_samples_split=5,
    random_state=42,
    n_jobs=-1
)
rf.fit(X_train_s, y_train)
print("   Training complete!")

# ─────────────────────────────────────────────
# 4. Evaluate
# ─────────────────────────────────────────────
print("\n[4/4] Evaluating model...")
y_pred = rf.predict(X_test_s)
acc = accuracy_score(y_test, y_pred)
cm  = confusion_matrix(y_test, y_pred)
report = classification_report(y_test, y_pred, target_names=["Benign","DDoS"], output_dict=True)

print(f"\n   Accuracy: {acc*100:.2f}%")
print(f"\n{classification_report(y_test, y_pred, target_names=['Benign','DDoS'])}")

# Feature importance
importances = dict(zip(FEATURES, rf.feature_importances_.tolist()))
top_features = sorted(importances.items(), key=lambda x: x[1], reverse=True)

# Save model artifacts
os.makedirs("model", exist_ok=True)
with open("model/rf_model.pkl",  "wb") as f: pickle.dump(rf, f)
with open("model/scaler.pkl",    "wb") as f: pickle.dump(scaler, f)

meta = {
    "accuracy": round(acc * 100, 2),
    "features": FEATURES,
    "confusion_matrix": cm.tolist(),
    "report": report,
    "feature_importance": {k: round(v, 4) for k, v in importances.items()},
    "top_features": [[k, round(v*100,2)] for k,v in top_features[:7]],
    "n_estimators": 150,
    "dataset_size": len(df),
}
with open("model/metadata.json", "w") as f: json.dump(meta, f, indent=2)

print("\n  Model saved to model/")
print("=" * 60)
print(f"  ACCURACY: {acc*100:.2f}%  |  Ready for inference")
print("=" * 60)
